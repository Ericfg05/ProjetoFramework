package com.alugaaqui.aluga_aqui;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlugaAquiApplicationTests {

	@Test
	void contextLoads() {
	}

}
