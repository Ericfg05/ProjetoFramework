package com.alugaaqui.aluga_aqui.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alugaaqui.aluga_aqui.dto.AluguelRequestDTO;
import com.alugaaqui.aluga_aqui.model.AlugueisModel;
import com.alugaaqui.aluga_aqui.service.AlugueisService;


@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/alugueis")

public class AlugueisController {

    @Autowired
    private AlugueisService alugueisService;

    @PostMapping("/cadastrarAlugueis")

    public ResponseEntity<AlugueisModel> registrarAluguel(@RequestBody AluguelRequestDTO dto) {
        AlugueisModel novoAluguel = alugueisService.registrarAluguel(
            dto.getIdCarro(),
            dto.getDataInicioAlugueis(),
            dto.getDataFimAlugueis(),
            dto.getObservacoesAlugueis(),
            dto.getNomeCliente(),
            dto.getEndereco()
        );
        return new ResponseEntity<>(novoAluguel, HttpStatus.CREATED);
    }


    @GetMapping
    public ResponseEntity<List<AlugueisModel>> listarTodosAlugueis() {
        List<AlugueisModel> alugueis = alugueisService.listarTodosAlugueis();
        return ResponseEntity.ok(alugueis);
    }


    @GetMapping("/{idAluguel}")
    public ResponseEntity<AlugueisModel> buscarAluguelPorId(@PathVariable Integer idAluguel) {
        Optional<AlugueisModel> aluguelOpt = alugueisService.buscarAluguelPorId(idAluguel);
        return aluguelOpt.map(ResponseEntity::ok)
                         .orElseGet(() -> ResponseEntity.notFound().build());
    }

    
    // Processar a devolução de um carro e finalizar o aluguel.
    
    @PutMapping("/{idAluguel}/finalizar")
    public ResponseEntity<AlugueisModel> processarDevolucaoEFinalizarAluguel(@PathVariable Integer idAluguel) {
        AlugueisModel aluguel = alugueisService.processarDevolucaoEFinalizarAluguel(idAluguel);
        return ResponseEntity.ok(aluguel);
    }

}