package com.alugaaqui.aluga_aqui.dto;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AluguelRequestDTO {

    @JsonProperty("id_carro")
    private Long idCarro;

    private LocalDate dataInicioAlugueis;
    private LocalDate dataFimAlugueis;
    private String observacoesAlugueis;
    private String nomeCliente;
    private String endereco;
}