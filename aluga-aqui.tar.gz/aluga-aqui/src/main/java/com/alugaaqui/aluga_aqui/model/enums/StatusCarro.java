package com.alugaaqui.aluga_aqui.model.enums;

public enum StatusCarro {
    DISPONIVEL,
    INDISPONIVEL;
}
