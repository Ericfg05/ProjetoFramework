// package com.alugaaqui.aluga_aqui.repositories;

// import org.springframework.data.jpa.repository.JpaRepository;

// import com.alugaaqui.aluga_aqui.model.ClientesModel;


// public interface ClientesRepositories extends JpaRepository<ClientesModel, Long> {
//     // Declaração dos métodos
//     // Optional<ClientesModel> 
//     /*Optional<ClientesModel> findByCpf(String cpf); 
//     Optional<ClientesModel> findByEmail(String email);
//     Optional<ClientesModel> findByNomeCompletosContainingIgnoreCase(String nomeParcial);
//     List<ClientesModel> findByNomeCompletoContainingIgnoreCase(String nomeParcial);*/

// }